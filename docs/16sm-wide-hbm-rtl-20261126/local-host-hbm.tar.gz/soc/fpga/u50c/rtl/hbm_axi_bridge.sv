`include "axi4_if.svh"

module hbm_axi_bridge (
    input  logic       clk_cpu,
    input  logic       resetn_cpu,
    input  logic       clk225,
    input  logic       resetn225,
    input  logic       clk100,
    input  logic       resetn100,
    output logic       hbm_ready,
    output logic       hbm_cattrip,
    output logic [6:0] hbm_temp,
    input  logic       axi_debug_clear,
    output logic [15:0] axi_debug,
    axi4_if.slave gpu0,
    axi4_if.slave gpu1,
    axi4_if.slave      s_axi
);
    logic [31:0] dw_awaddr, dw_araddr;
    logic [7:0]  dw_awlen, dw_arlen;
    logic [2:0]  dw_awsize, dw_arsize;
    logic [1:0]  dw_awburst, dw_arburst;
    logic        dw_awlock, dw_arlock;
    logic [3:0]  dw_awcache, dw_arcache, dw_awregion, dw_arregion;
    logic [2:0]  dw_awprot, dw_arprot;
    logic [3:0]  dw_awqos, dw_arqos;
    logic        dw_awvalid, dw_awready;
    logic [255:0] dw_wdata;
    logic [31:0]  dw_wstrb;
    logic         dw_wlast, dw_wvalid, dw_wready;
    logic [1:0]   dw_bresp;
    logic         dw_bvalid, dw_bready;
    logic         dw_arvalid, dw_arready;
    logic [255:0] dw_rdata;
    logic [1:0]   dw_rresp;
    logic         dw_rlast, dw_rvalid, dw_rready;

    logic [31:0] hb_awaddr, hb_araddr;
    logic [7:0]  hb_awlen, hb_arlen;
    logic [2:0]  hb_awsize, hb_arsize;
    logic [1:0]  hb_awburst, hb_arburst;
    logic        hb_awlock, hb_arlock;
    logic [3:0]  hb_awcache, hb_arcache, hb_awregion, hb_arregion;
    logic [2:0]  hb_awprot, hb_arprot;
    logic [3:0]  hb_awqos, hb_arqos;
    logic        hb_awvalid, hb_awready;
    logic [255:0] hb_wdata;
    logic [31:0]  hb_wstrb;
    logic         hb_wlast, hb_wvalid, hb_wready;
    logic [1:0]   hb_bresp;
    logic         hb_bvalid, hb_bready;
    logic         hb_arvalid, hb_arready;
    logic [255:0] hb_rdata;
    logic [1:0]   hb_rresp;
    logic         hb_rlast, hb_rvalid, hb_rready;
    logic [5:0]   hbm_bid, hbm_rid;
    logic [31:0]  apb_rdata;
    logic         apb_ready, apb_slverr, apb_complete;
    logic [31:0]  hbm_rparity;
    logic [13:0]  axi_seen;
    logic [31:0] pc_awaddr, pc_araddr;
    logic [3:0] pc_awlen, pc_arlen;
    logic [2:0] pc_awsize, pc_arsize;
    logic [1:0] pc_awburst, pc_arburst;
    logic pc_awvalid, pc_awready, pc_arvalid, pc_arready;
    logic [255:0] pc_wdata, pc_rdata;
    logic [31:0] pc_wstrb;
    logic pc_wlast, pc_wvalid, pc_wready;
    logic pc_bvalid, pc_bready, pc_rlast, pc_rvalid, pc_rready;
    logic [1:0] pc_bresp, pc_rresp;

    // Sticky hardware evidence for each stage of a transaction.  The VIO can
    // be read after a JTAG transaction times out, without needing an ILA
    // trigger to be armed at exactly the right cycle.
    always_ff @(posedge clk225) begin
        if (!resetn225 || axi_debug_clear) begin
            axi_seen <= 14'b0;
        end else begin
            axi_seen <= axi_seen | {
                hb_rvalid && hb_rready,
                hb_rvalid,
                hb_arvalid && hb_arready,
                hb_arready,
                hb_arvalid,
                hb_bvalid && hb_bready,
                hb_bready,
                hb_bvalid,
                hb_wvalid && hb_wready,
                hb_wready,
                hb_wvalid,
                hb_awvalid && hb_awready,
                hb_awready,
                hb_awvalid
            };
        end
    end

    wire apb_complete225;
    xpm_cdc_single #(.DEST_SYNC_FF(3), .SRC_INPUT_REG(0), .INIT_SYNC_FF(0))
    u_apb_done_debug_sync (.src_clk(1'b0), .src_in(apb_complete),
                          .dest_clk(clk225), .dest_out(apb_complete225));
    assign axi_debug = {axi_seen, apb_complete225, resetn225};

    axi_dwidth_converter_0 u_width_converter (
        .s_axi_aclk     (clk_cpu),
        .s_axi_aresetn  (resetn_cpu),
        .s_axi_awid     (s_axi.awid),
        .s_axi_awaddr   (s_axi.awaddr),
        .s_axi_awlen    (s_axi.awlen),
        .s_axi_awsize   (s_axi.awsize),
        .s_axi_awburst  (s_axi.awburst),
        .s_axi_awlock   (s_axi.awlock),
        // PACKING_LEVEL=Always handles single-byte/halfword accesses too.
        // This port only serves HBM RAM; MMIO is decoded before the upsizer.
        .s_axi_awcache  (s_axi.awcache),
        .s_axi_awprot   (s_axi.awprot),
        .s_axi_awregion (4'b0),
        .s_axi_awqos    (s_axi.awqos),
        .s_axi_awvalid  (s_axi.awvalid),
        .s_axi_awready  (s_axi.awready),
        .s_axi_wdata    (s_axi.wdata),
        .s_axi_wstrb    (s_axi.wstrb),
        .s_axi_wlast    (s_axi.wlast),
        .s_axi_wvalid   (s_axi.wvalid),
        .s_axi_wready   (s_axi.wready),
        .s_axi_bid      (s_axi.bid),
        .s_axi_bresp    (s_axi.bresp),
        .s_axi_bvalid   (s_axi.bvalid),
        .s_axi_bready   (s_axi.bready),
        .s_axi_arid     (s_axi.arid),
        .s_axi_araddr   (s_axi.araddr),
        .s_axi_arlen    (s_axi.arlen),
        .s_axi_arsize   (s_axi.arsize),
        .s_axi_arburst  (s_axi.arburst),
        .s_axi_arlock   (s_axi.arlock),
        .s_axi_arcache  (s_axi.arcache),
        .s_axi_arprot   (s_axi.arprot),
        .s_axi_arregion (4'b0),
        .s_axi_arqos    (s_axi.arqos),
        .s_axi_arvalid  (s_axi.arvalid),
        .s_axi_arready  (s_axi.arready),
        .s_axi_rid      (s_axi.rid),
        .s_axi_rdata    (s_axi.rdata),
        .s_axi_rresp    (s_axi.rresp),
        .s_axi_rlast    (s_axi.rlast),
        .s_axi_rvalid   (s_axi.rvalid),
        .s_axi_rready   (s_axi.rready),
        .m_axi_awaddr   (dw_awaddr),
        .m_axi_awlen    (dw_awlen),
        .m_axi_awsize   (dw_awsize),
        .m_axi_awburst  (dw_awburst),
        .m_axi_awlock   (dw_awlock),
        .m_axi_awcache  (dw_awcache),
        .m_axi_awprot   (dw_awprot),
        .m_axi_awregion (dw_awregion),
        .m_axi_awqos    (dw_awqos),
        .m_axi_awvalid  (dw_awvalid),
        .m_axi_awready  (dw_awready),
        .m_axi_wdata    (dw_wdata),
        .m_axi_wstrb    (dw_wstrb),
        .m_axi_wlast    (dw_wlast),
        .m_axi_wvalid   (dw_wvalid),
        .m_axi_wready   (dw_wready),
        .m_axi_bresp    (dw_bresp),
        .m_axi_bvalid   (dw_bvalid),
        .m_axi_bready   (dw_bready),
        .m_axi_araddr   (dw_araddr),
        .m_axi_arlen    (dw_arlen),
        .m_axi_arsize   (dw_arsize),
        .m_axi_arburst  (dw_arburst),
        .m_axi_arlock   (dw_arlock),
        .m_axi_arcache  (dw_arcache),
        .m_axi_arprot   (dw_arprot),
        .m_axi_arregion (dw_arregion),
        .m_axi_arqos    (dw_arqos),
        .m_axi_arvalid  (dw_arvalid),
        .m_axi_arready  (dw_arready),
        .m_axi_rdata    (dw_rdata),
        .m_axi_rresp    (dw_rresp),
        .m_axi_rlast    (dw_rlast),
        .m_axi_rvalid   (dw_rvalid),
        .m_axi_rready   (dw_rready)
    );

    // The width converter retains the 4-bit source ID internally, so its wide
    // side is ID-less.  The clock converter is configured the same way.
    axi_clock_converter_0 u_clock_converter (
        .s_axi_aclk     (clk_cpu),
        .s_axi_aresetn  (resetn_cpu),
        .s_axi_awaddr   (dw_awaddr), .s_axi_awlen(dw_awlen),
        .s_axi_awsize   (dw_awsize), .s_axi_awburst(dw_awburst),
        .s_axi_awlock   (dw_awlock), .s_axi_awcache(dw_awcache),
        .s_axi_awprot   (dw_awprot), .s_axi_awregion(dw_awregion),
        .s_axi_awqos    (dw_awqos), .s_axi_awvalid(dw_awvalid),
        .s_axi_awready  (dw_awready),
        .s_axi_wdata    (dw_wdata), .s_axi_wstrb(dw_wstrb),
        .s_axi_wlast    (dw_wlast), .s_axi_wvalid(dw_wvalid),
        .s_axi_wready   (dw_wready),
        .s_axi_bresp    (dw_bresp), .s_axi_bvalid(dw_bvalid),
        .s_axi_bready   (dw_bready),
        .s_axi_araddr   (dw_araddr), .s_axi_arlen(dw_arlen),
        .s_axi_arsize   (dw_arsize), .s_axi_arburst(dw_arburst),
        .s_axi_arlock   (dw_arlock), .s_axi_arcache(dw_arcache),
        .s_axi_arprot   (dw_arprot), .s_axi_arregion(dw_arregion),
        .s_axi_arqos    (dw_arqos), .s_axi_arvalid(dw_arvalid),
        .s_axi_arready  (dw_arready),
        .s_axi_rdata    (dw_rdata), .s_axi_rresp(dw_rresp),
        .s_axi_rlast    (dw_rlast), .s_axi_rvalid(dw_rvalid),
        .s_axi_rready   (dw_rready),
        .m_axi_aclk     (clk225),
        .m_axi_aresetn  (resetn225),
        .m_axi_awaddr   (hb_awaddr), .m_axi_awlen(hb_awlen),
        .m_axi_awsize   (hb_awsize), .m_axi_awburst(hb_awburst),
        .m_axi_awlock   (hb_awlock), .m_axi_awcache(hb_awcache),
        .m_axi_awprot   (hb_awprot), .m_axi_awregion(hb_awregion),
        .m_axi_awqos    (hb_awqos), .m_axi_awvalid(hb_awvalid),
        .m_axi_awready  (hb_awready),
        .m_axi_wdata    (hb_wdata), .m_axi_wstrb(hb_wstrb),
        .m_axi_wlast    (hb_wlast), .m_axi_wvalid(hb_wvalid),
        .m_axi_wready   (hb_wready),
        .m_axi_bresp    (hb_bresp), .m_axi_bvalid(hb_bvalid),
        .m_axi_bready   (hb_bready),
        .m_axi_araddr   (hb_araddr), .m_axi_arlen(hb_arlen),
        .m_axi_arsize   (hb_arsize), .m_axi_arburst(hb_arburst),
        .m_axi_arlock   (hb_arlock), .m_axi_arcache(hb_arcache),
        .m_axi_arprot   (hb_arprot), .m_axi_arregion(hb_arregion),
        .m_axi_arqos    (hb_arqos), .m_axi_arvalid(hb_arvalid),
        .m_axi_arready  (hb_arready),
        .m_axi_rdata    (hb_rdata), .m_axi_rresp(hb_rresp),
        .m_axi_rlast    (hb_rlast), .m_axi_rvalid(hb_rvalid),
        .m_axi_rready   (hb_rready)
    );

    axi_protocol_converter_0 u_axi3_converter (
        .aclk(clk225), .aresetn(resetn225),
        .s_axi_awaddr(hb_awaddr), .s_axi_awlen(hb_awlen),
        .s_axi_awsize(hb_awsize), .s_axi_awburst(hb_awburst),
        .s_axi_awlock(hb_awlock), .s_axi_awcache(hb_awcache),
        .s_axi_awprot(hb_awprot), .s_axi_awregion(hb_awregion),
        .s_axi_awqos(hb_awqos), .s_axi_awvalid(hb_awvalid), .s_axi_awready(hb_awready),
        .s_axi_wdata(hb_wdata), .s_axi_wstrb(hb_wstrb),
        .s_axi_wlast(hb_wlast), .s_axi_wvalid(hb_wvalid), .s_axi_wready(hb_wready),
        .s_axi_bresp(hb_bresp), .s_axi_bvalid(hb_bvalid), .s_axi_bready(hb_bready),
        .s_axi_araddr(hb_araddr), .s_axi_arlen(hb_arlen),
        .s_axi_arsize(hb_arsize), .s_axi_arburst(hb_arburst),
        .s_axi_arlock(hb_arlock), .s_axi_arcache(hb_arcache),
        .s_axi_arprot(hb_arprot), .s_axi_arregion(hb_arregion),
        .s_axi_arqos(hb_arqos), .s_axi_arvalid(hb_arvalid), .s_axi_arready(hb_arready),
        .s_axi_rdata(hb_rdata), .s_axi_rresp(hb_rresp),
        .s_axi_rlast(hb_rlast), .s_axi_rvalid(hb_rvalid), .s_axi_rready(hb_rready),
        .m_axi_awaddr(pc_awaddr), .m_axi_awlen(pc_awlen),
        .m_axi_awsize(pc_awsize), .m_axi_awburst(pc_awburst),
        .m_axi_awvalid(pc_awvalid), .m_axi_awready(pc_awready),
        .m_axi_wdata(pc_wdata), .m_axi_wstrb(pc_wstrb),
        .m_axi_wlast(pc_wlast), .m_axi_wvalid(pc_wvalid), .m_axi_wready(pc_wready),
        .m_axi_bresp(pc_bresp), .m_axi_bvalid(pc_bvalid), .m_axi_bready(pc_bready),
        .m_axi_araddr(pc_araddr), .m_axi_arlen(pc_arlen),
        .m_axi_arsize(pc_arsize), .m_axi_arburst(pc_arburst),
        .m_axi_arvalid(pc_arvalid), .m_axi_arready(pc_arready),
        .m_axi_rdata(pc_rdata), .m_axi_rresp(pc_rresp),
        .m_axi_rlast(pc_rlast), .m_axi_rvalid(pc_rvalid), .m_axi_rready(pc_rready)
    );

    // The upsizer keeps the original byte offset for selecting return lanes.
    // HBM itself requires 32-byte-aligned addresses and full-width AxSIZE=5.
    axi4_if #(.DATA_WIDTH(256)) gpu_pc0();
    logic [5:0] gpu_bid0, gpu_rid0;
    assign gpu_pc0.bid = gpu_bid0[3:0];
    assign gpu_pc0.rid = gpu_rid0[3:0];
    gpu_hbm_path u_gpu_path0(.clk_cpu, .resetn_cpu, .clk225, .resetn225, .src(gpu0), .pc(gpu_pc0));
    axi4_if #(.DATA_WIDTH(256)) gpu_pc1();
    logic [5:0] gpu_bid1, gpu_rid1;
    assign gpu_pc1.bid = gpu_bid1[3:0];
    assign gpu_pc1.rid = gpu_rid1[3:0];
    gpu_hbm_path u_gpu_path1(.clk_cpu, .resetn_cpu, .clk225, .resetn225, .src(gpu1), .pc(gpu_pc1));
    function automatic logic stack_for_host(input logic [31:0] addr);
        return addr >= 32'h01000000 && addr < 32'h1fe00000 && addr[12];
    endfunction
    logic init1, trip0, trip1;
    logic [6:0] temp0, temp1;
    assign hbm_cattrip = trip0 | trip1;
    assign hbm_temp = temp0 > temp1 ? temp0 : temp1;

    axi4_if #(.DATA_WIDTH(256)) host0(), host1();
    logic read_bank, write_bank, read_active, write_active;
    wire ar_bank = stack_for_host(pc_araddr);
    wire aw_bank = stack_for_host(pc_awaddr);
    always_ff @(posedge clk225) begin
        if (!resetn225) begin
            read_active <= 0; write_active <= 0; read_bank <= 0; write_bank <= 0;
        end else begin
            if (pc_arvalid && pc_arready) begin read_active <= 1; read_bank <= ar_bank; end
            if (pc_rvalid && pc_rready && pc_rlast) read_active <= 0;
            if (pc_awvalid && pc_awready) begin write_active <= 1; write_bank <= aw_bank; end
            if (pc_bvalid && pc_bready) write_active <= 0;
        end
    end
    assign host0.awaddr = pc_awaddr;
    assign host1.awaddr = pc_awaddr;
    assign host0.awlen = pc_awlen;
    assign host1.awlen = pc_awlen;
    assign host0.awsize = pc_awsize;
    assign host1.awsize = pc_awsize;
    assign host0.awburst = pc_awburst;
    assign host1.awburst = pc_awburst;
    assign host0.awvalid = pc_awvalid && aw_bank == 1'b0 && !write_active;
    assign host1.awvalid = pc_awvalid && aw_bank == 1'b1 && !write_active;
    assign pc_awready = !write_active && (aw_bank ? host1.awready : host0.awready);
    assign host0.wdata = pc_wdata;
    assign host1.wdata = pc_wdata;
    assign host0.wstrb = pc_wstrb;
    assign host1.wstrb = pc_wstrb;
    assign host0.wlast = pc_wlast;
    assign host1.wlast = pc_wlast;
    assign host0.wvalid = pc_wvalid && write_bank == 1'b0 && write_active;
    assign host1.wvalid = pc_wvalid && write_bank == 1'b1 && write_active;
    assign pc_wready = write_active && (write_bank ? host1.wready : host0.wready);
    assign pc_bresp = (write_bank ? host1.bresp : host0.bresp);
    assign pc_bvalid = write_active && (write_bank ? host1.bvalid : host0.bvalid);
    assign host0.bready = pc_bready && write_bank == 1'b0 && write_active;
    assign host1.bready = pc_bready && write_bank == 1'b1 && write_active;
    assign host0.araddr = pc_araddr;
    assign host1.araddr = pc_araddr;
    assign host0.arlen = pc_arlen;
    assign host1.arlen = pc_arlen;
    assign host0.arsize = pc_arsize;
    assign host1.arsize = pc_arsize;
    assign host0.arburst = pc_arburst;
    assign host1.arburst = pc_arburst;
    assign host0.arvalid = pc_arvalid && ar_bank == 1'b0 && !read_active;
    assign host1.arvalid = pc_arvalid && ar_bank == 1'b1 && !read_active;
    assign pc_arready = !read_active && (ar_bank ? host1.arready : host0.arready);
    assign pc_rdata = (read_bank ? host1.rdata : host0.rdata);
    assign pc_rresp = (read_bank ? host1.rresp : host0.rresp);
    assign pc_rlast = (read_bank ? host1.rlast : host0.rlast);
    assign pc_rvalid = read_active && (read_bank ? host1.rvalid : host0.rvalid);
    assign host0.rready = pc_rready && read_bank == 1'b0 && read_active;
    assign host1.rready = pc_rready && read_bank == 1'b1 && read_active;
    hbm_0 u_hbm (
        .AXI_16_ACLK(clk225),
        .AXI_16_ARESET_N(resetn225),
        .AXI_16_WDATA_PARITY(32'b0),
        .AXI_16_RDATA_PARITY(),
        .AXI_16_AWID(6'b0),
        .AXI_16_AWADDR({1'b1, host1.awaddr}),
        .AXI_16_AWLEN(host1.awlen[3:0]),
        .AXI_16_AWSIZE(host1.awsize),
        .AXI_16_AWBURST(host1.awburst),
        .AXI_16_AWVALID(host1.awvalid),
        .AXI_16_AWREADY(host1.awready),
        .AXI_16_WDATA(host1.wdata),
        .AXI_16_WSTRB(host1.wstrb),
        .AXI_16_WLAST(host1.wlast),
        .AXI_16_WVALID(host1.wvalid),
        .AXI_16_WREADY(host1.wready),
        .AXI_16_BID(),
        .AXI_16_BRESP(host1.bresp),
        .AXI_16_BVALID(host1.bvalid),
        .AXI_16_BREADY(host1.bready),
        .AXI_16_ARID(6'b0),
        .AXI_16_ARADDR({1'b1, host1.araddr}),
        .AXI_16_ARLEN(host1.arlen[3:0]),
        .AXI_16_ARSIZE(host1.arsize),
        .AXI_16_ARBURST(host1.arburst),
        .AXI_16_ARVALID(host1.arvalid),
        .AXI_16_ARREADY(host1.arready),
        .AXI_16_RID(),
        .AXI_16_RDATA(host1.rdata),
        .AXI_16_RRESP(host1.rresp),
        .AXI_16_RLAST(host1.rlast),
        .AXI_16_RVALID(host1.rvalid),
        .AXI_16_RREADY(host1.rready),
        .HBM_REF_CLK_1(clk100), .APB_1_PCLK(clk100), .APB_1_PRESET_N(resetn100),
        .APB_1_PWDATA(32'b0), .APB_1_PADDR(22'b0), .APB_1_PENABLE(1'b0),
        .APB_1_PSEL(1'b0), .APB_1_PWRITE(1'b0), .apb_complete_1(init1),
        .DRAM_1_STAT_CATTRIP(trip1), .DRAM_1_STAT_TEMP(temp1),
        .AXI_01_ACLK(clk225),
        .AXI_01_ARESET_N(resetn225),
        .AXI_01_WDATA_PARITY(32'b0),
        .AXI_01_RDATA_PARITY(),
        .AXI_01_AWID({2'b0, gpu_pc0.awid}),
        .AXI_01_AWADDR({1'b0, gpu_pc0.awaddr}),
        .AXI_01_AWLEN(gpu_pc0.awlen[3:0]),
        .AXI_01_AWSIZE(gpu_pc0.awsize),
        .AXI_01_AWBURST(gpu_pc0.awburst),
        .AXI_01_AWVALID(gpu_pc0.awvalid),
        .AXI_01_AWREADY(gpu_pc0.awready),
        .AXI_01_WDATA(gpu_pc0.wdata),
        .AXI_01_WSTRB(gpu_pc0.wstrb),
        .AXI_01_WLAST(gpu_pc0.wlast),
        .AXI_01_WVALID(gpu_pc0.wvalid),
        .AXI_01_WREADY(gpu_pc0.wready),
        .AXI_01_BID(gpu_bid0),
        .AXI_01_BRESP(gpu_pc0.bresp),
        .AXI_01_BVALID(gpu_pc0.bvalid),
        .AXI_01_BREADY(gpu_pc0.bready),
        .AXI_01_ARID({2'b0, gpu_pc0.arid}),
        .AXI_01_ARADDR({1'b0, gpu_pc0.araddr}),
        .AXI_01_ARLEN(gpu_pc0.arlen[3:0]),
        .AXI_01_ARSIZE(gpu_pc0.arsize),
        .AXI_01_ARBURST(gpu_pc0.arburst),
        .AXI_01_ARVALID(gpu_pc0.arvalid),
        .AXI_01_ARREADY(gpu_pc0.arready),
        .AXI_01_RID(gpu_rid0),
        .AXI_01_RDATA(gpu_pc0.rdata),
        .AXI_01_RRESP(gpu_pc0.rresp),
        .AXI_01_RLAST(gpu_pc0.rlast),
        .AXI_01_RVALID(gpu_pc0.rvalid),
        .AXI_01_RREADY(gpu_pc0.rready),
        .AXI_17_ACLK(clk225),
        .AXI_17_ARESET_N(resetn225),
        .AXI_17_WDATA_PARITY(32'b0),
        .AXI_17_RDATA_PARITY(),
        .AXI_17_AWID({2'b0, gpu_pc1.awid}),
        .AXI_17_AWADDR({1'b1, gpu_pc1.awaddr}),
        .AXI_17_AWLEN(gpu_pc1.awlen[3:0]),
        .AXI_17_AWSIZE(gpu_pc1.awsize),
        .AXI_17_AWBURST(gpu_pc1.awburst),
        .AXI_17_AWVALID(gpu_pc1.awvalid),
        .AXI_17_AWREADY(gpu_pc1.awready),
        .AXI_17_WDATA(gpu_pc1.wdata),
        .AXI_17_WSTRB(gpu_pc1.wstrb),
        .AXI_17_WLAST(gpu_pc1.wlast),
        .AXI_17_WVALID(gpu_pc1.wvalid),
        .AXI_17_WREADY(gpu_pc1.wready),
        .AXI_17_BID(gpu_bid1),
        .AXI_17_BRESP(gpu_pc1.bresp),
        .AXI_17_BVALID(gpu_pc1.bvalid),
        .AXI_17_BREADY(gpu_pc1.bready),
        .AXI_17_ARID({2'b0, gpu_pc1.arid}),
        .AXI_17_ARADDR({1'b1, gpu_pc1.araddr}),
        .AXI_17_ARLEN(gpu_pc1.arlen[3:0]),
        .AXI_17_ARSIZE(gpu_pc1.arsize),
        .AXI_17_ARBURST(gpu_pc1.arburst),
        .AXI_17_ARVALID(gpu_pc1.arvalid),
        .AXI_17_ARREADY(gpu_pc1.arready),
        .AXI_17_RID(gpu_rid1),
        .AXI_17_RDATA(gpu_pc1.rdata),
        .AXI_17_RRESP(gpu_pc1.rresp),
        .AXI_17_RLAST(gpu_pc1.rlast),
        .AXI_17_RVALID(gpu_pc1.rvalid),
        .AXI_17_RREADY(gpu_pc1.rready),
        .HBM_REF_CLK_0        (clk100),
        .AXI_00_ACLK          (clk225),
        .AXI_00_ARESET_N      (resetn225),
        .AXI_00_ARADDR        ({1'b0, host0.araddr[31:5], 5'b0}),
        .AXI_00_ARBURST       (host0.arburst),
        .AXI_00_ARID          (6'b0),
        .AXI_00_ARLEN         (host0.arlen[3:0]),
        .AXI_00_ARSIZE        (host0.arsize),
        .AXI_00_ARVALID       (host0.arvalid),
        .AXI_00_ARREADY       (host0.arready),
        .AXI_00_RDATA_PARITY  (hbm_rparity),
        .AXI_00_RDATA         (host0.rdata),
        .AXI_00_RID           (hbm_rid),
        .AXI_00_RLAST         (host0.rlast),
        .AXI_00_RRESP         (host0.rresp),
        .AXI_00_RVALID        (host0.rvalid),
        .AXI_00_RREADY        (host0.rready),
        .AXI_00_AWADDR        ({1'b0, host0.awaddr[31:5], 5'b0}),
        .AXI_00_AWBURST       (host0.awburst),
        .AXI_00_AWID          (6'b0),
        .AXI_00_AWLEN         (host0.awlen[3:0]),
        .AXI_00_AWSIZE        (host0.awsize),
        .AXI_00_AWVALID       (host0.awvalid),
        .AXI_00_AWREADY       (host0.awready),
        .AXI_00_WDATA         (host0.wdata),
        .AXI_00_WLAST         (host0.wlast),
        .AXI_00_WSTRB         (host0.wstrb),
        .AXI_00_WDATA_PARITY  (32'b0),
        .AXI_00_WVALID        (host0.wvalid),
        .AXI_00_WREADY        (host0.wready),
        .AXI_00_BID           (hbm_bid),
        .AXI_00_BRESP         (host0.bresp),
        .AXI_00_BVALID        (host0.bvalid),
        .AXI_00_BREADY        (host0.bready),
        .APB_0_PWDATA         (32'b0),
        .APB_0_PADDR          (22'b0),
        .APB_0_PCLK           (clk100),
        .APB_0_PENABLE        (1'b0),
        .APB_0_PRESET_N       (resetn100),
        .APB_0_PSEL           (1'b0),
        .APB_0_PWRITE         (1'b0),
        .APB_0_PRDATA         (apb_rdata),
        .APB_0_PREADY         (apb_ready),
        .APB_0_PSLVERR        (apb_slverr),
        .apb_complete_0       (apb_complete),
        .DRAM_0_STAT_CATTRIP  (trip0),
        .DRAM_0_STAT_TEMP     (temp0)
    );

    assign hbm_ready = apb_complete && init1;
endmodule
