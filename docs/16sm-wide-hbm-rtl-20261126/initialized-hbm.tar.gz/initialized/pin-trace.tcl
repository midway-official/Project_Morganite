open_vcd pin-trace.vcd
foreach port {01 17 00 16} {
    foreach obj [get_objects /dual_hbm_tb/dut/u_hbm/AXI_${port}_*] {
        log_vcd $obj
    }
}
run 55 us
close_vcd
quit
