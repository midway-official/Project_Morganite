`include "axi4_if.svh"

module u50c_top (
    input  wire SYSCLK3_P,
    input  wire SYSCLK3_N,
    output wire HBM_CATTRIP
);
    wire clk100_ibuf;
    wire clk100;
    wire clk_cpu;
    wire clk225;
    wire clk_locked;
    wire hbm_ready;
    wire hbm_cattrip_raw;
    wire [6:0] hbm_temp;
    wire [15:0] hbm_axi_debug;
    wire uart_irq;
    wire cpu_run;
    wire cpu_reset;
    wire cpu_idle;
    wire cpu_enable;
    wire vio_force_cpu_reset;
    wire vio_clear_axi_debug;
    wire [7:0] ext_int;

    (* ASYNC_REG = "TRUE" *) logic [2:0] hbm_ready_pipe = 3'b0;
    (* ASYNC_REG = "TRUE" *) logic [1:0] force_cpu_reset_pipe = 2'b0;
    wire resetn100;
    wire resetn_cpu;
    wire resetn225;
    wire [7:0] status_raw;
    wire [7:0] status_ref;
    wire hbm_ready_cpu = hbm_ready_pipe[2];

    axi4_if #(.ADDR_WIDTH(32), .DATA_WIDTH(32), .ID_WIDTH(4)) cpu_axi();
    axi4_if #(.ADDR_WIDTH(32), .DATA_WIDTH(32), .ID_WIDTH(4)) jtag_axi();
    axi4_if #(.ADDR_WIDTH(32), .DATA_WIDTH(32), .ID_WIDTH(4)) mem_axi();
    axi4_if #(.ADDR_WIDTH(32), .DATA_WIDTH(32), .ID_WIDTH(4)) periph_axi();

    IBUFDS #(
        .DIFF_TERM("TRUE"),
        .IBUF_LOW_PWR("FALSE")
    ) u_hbm_refclk_ibuf (
        .I (SYSCLK3_P),
        .IB(SYSCLK3_N),
        .O (clk100_ibuf)
    );

    BUFG u_hbm_refclk_bufg (
        .I(clk100_ibuf),
        .O(clk100)
    );

    clk_wiz_0 u_clock_gen (
        .clk_out1(clk_cpu),
        .clk_out2(clk225),
        .locked  (clk_locked),
        .clk_in1 (clk100)
    );

    u50c_reset_control u_reset_control (
        .clk_ref(clk100), .clk_cpu(clk_cpu), .clk_hbm(clk225), .clk_locked(clk_locked),
        .resetn_ref(resetn100), .resetn_cpu(resetn_cpu), .resetn_hbm(resetn225)
    );
    always_ff @(posedge clk_cpu) begin
        if (!resetn_cpu) hbm_ready_pipe <= 3'b0;
        else           hbm_ready_pipe <= {hbm_ready_pipe[1:0], hbm_ready};
        force_cpu_reset_pipe <= {force_cpu_reset_pipe[0], vio_force_cpu_reset};
    end

    // NEMU's 16550 model raises external interrupt line 1.
    assign ext_int = {6'b0, uart_irq, 1'b0};
    assign cpu_enable = cpu_run && !force_cpu_reset_pipe[1];
    assign cpu_reset = !resetn_cpu || !hbm_ready_cpu || (!cpu_enable && cpu_idle);

    aurora_axi_wrapper u_cpu (
        .clk     (clk_cpu),
        .reset   (cpu_reset),
        .ext_int (ext_int),
        .m_axi   (cpu_axi)
    );

    jtag_axi_master u_jtag (
        .clk    (clk_cpu),
        .resetn (resetn_cpu),
        .m_axi  (jtag_axi)
    );

    axi4_if host_mem();
    axi4_if host_io();

    axi_arbiter_2m2s u_fabric (
        .clk    (clk_cpu),
        .resetn (resetn_cpu),
        .cpu_enable(cpu_enable),
        .cpu_idle(cpu_idle),
        .cpu    (cpu_axi),
        .jtag   (jtag_axi),
        .mem    (host_mem),
        .periph (host_io)
    );

    MorganiteBoard u_gpu_soc (
        .clock(clk_cpu),
        .reset(!resetn_cpu),
        .io_cpuMemory_ar_ready(host_mem.arready),
        .io_cpuMemory_ar_valid(host_mem.arvalid),
        .io_cpuMemory_ar_bits_addr(host_mem.araddr),
        .io_cpuMemory_ar_bits_id(host_mem.arid),
        .io_cpuMemory_ar_bits_len(host_mem.arlen),
        .io_cpuMemory_ar_bits_size(host_mem.arsize),
        .io_cpuMemory_ar_bits_burst(host_mem.arburst),
        .io_cpuMemory_ar_bits_lock(host_mem.arlock),
        .io_cpuMemory_ar_bits_cache(host_mem.arcache),
        .io_cpuMemory_ar_bits_prot(host_mem.arprot),
        .io_cpuMemory_ar_bits_qos(host_mem.arqos),
        .io_cpuMemory_aw_ready(host_mem.awready),
        .io_cpuMemory_aw_valid(host_mem.awvalid),
        .io_cpuMemory_aw_bits_addr(host_mem.awaddr),
        .io_cpuMemory_aw_bits_id(host_mem.awid),
        .io_cpuMemory_aw_bits_len(host_mem.awlen),
        .io_cpuMemory_aw_bits_size(host_mem.awsize),
        .io_cpuMemory_aw_bits_burst(host_mem.awburst),
        .io_cpuMemory_aw_bits_lock(host_mem.awlock),
        .io_cpuMemory_aw_bits_cache(host_mem.awcache),
        .io_cpuMemory_aw_bits_prot(host_mem.awprot),
        .io_cpuMemory_aw_bits_qos(host_mem.awqos),
        .io_cpuMemory_w_ready(host_mem.wready),
        .io_cpuMemory_w_valid(host_mem.wvalid),
        .io_cpuMemory_w_bits_data(host_mem.wdata),
        .io_cpuMemory_w_bits_strb(host_mem.wstrb),
        .io_cpuMemory_w_bits_last(host_mem.wlast),
        .io_cpuMemory_b_ready(host_mem.bready),
        .io_cpuMemory_b_valid(host_mem.bvalid),
        .io_cpuMemory_b_bits_id(host_mem.bid),
        .io_cpuMemory_b_bits_resp(host_mem.bresp),
        .io_cpuMemory_r_ready(host_mem.rready),
        .io_cpuMemory_r_valid(host_mem.rvalid),
        .io_cpuMemory_r_bits_id(host_mem.rid),
        .io_cpuMemory_r_bits_data(host_mem.rdata),
        .io_cpuMemory_r_bits_resp(host_mem.rresp),
        .io_cpuMemory_r_bits_last(host_mem.rlast),
        .io_peripheral_ar_ready(host_io.arready),
        .io_peripheral_ar_valid(host_io.arvalid),
        .io_peripheral_ar_bits_addr(host_io.araddr),
        .io_peripheral_ar_bits_id(host_io.arid),
        .io_peripheral_ar_bits_len(host_io.arlen),
        .io_peripheral_ar_bits_size(host_io.arsize),
        .io_peripheral_ar_bits_burst(host_io.arburst),
        .io_peripheral_ar_bits_lock(host_io.arlock),
        .io_peripheral_ar_bits_cache(host_io.arcache),
        .io_peripheral_ar_bits_prot(host_io.arprot),
        .io_peripheral_ar_bits_qos(host_io.arqos),
        .io_peripheral_aw_ready(host_io.awready),
        .io_peripheral_aw_valid(host_io.awvalid),
        .io_peripheral_aw_bits_addr(host_io.awaddr),
        .io_peripheral_aw_bits_id(host_io.awid),
        .io_peripheral_aw_bits_len(host_io.awlen),
        .io_peripheral_aw_bits_size(host_io.awsize),
        .io_peripheral_aw_bits_burst(host_io.awburst),
        .io_peripheral_aw_bits_lock(host_io.awlock),
        .io_peripheral_aw_bits_cache(host_io.awcache),
        .io_peripheral_aw_bits_prot(host_io.awprot),
        .io_peripheral_aw_bits_qos(host_io.awqos),
        .io_peripheral_w_ready(host_io.wready),
        .io_peripheral_w_valid(host_io.wvalid),
        .io_peripheral_w_bits_data(host_io.wdata),
        .io_peripheral_w_bits_strb(host_io.wstrb),
        .io_peripheral_w_bits_last(host_io.wlast),
        .io_peripheral_b_ready(host_io.bready),
        .io_peripheral_b_valid(host_io.bvalid),
        .io_peripheral_b_bits_id(host_io.bid),
        .io_peripheral_b_bits_resp(host_io.bresp),
        .io_peripheral_r_ready(host_io.rready),
        .io_peripheral_r_valid(host_io.rvalid),
        .io_peripheral_r_bits_id(host_io.rid),
        .io_peripheral_r_bits_data(host_io.rdata),
        .io_peripheral_r_bits_resp(host_io.rresp),
        .io_peripheral_r_bits_last(host_io.rlast),
        .io_hbm_ar_ready(mem_axi.arready),
        .io_hbm_ar_valid(mem_axi.arvalid),
        .io_hbm_ar_bits_addr(mem_axi.araddr),
        .io_hbm_ar_bits_id(mem_axi.arid),
        .io_hbm_ar_bits_len(mem_axi.arlen),
        .io_hbm_ar_bits_size(mem_axi.arsize),
        .io_hbm_ar_bits_burst(mem_axi.arburst),
        .io_hbm_ar_bits_lock(mem_axi.arlock),
        .io_hbm_ar_bits_cache(mem_axi.arcache),
        .io_hbm_ar_bits_prot(mem_axi.arprot),
        .io_hbm_ar_bits_qos(mem_axi.arqos),
        .io_hbm_aw_ready(mem_axi.awready),
        .io_hbm_aw_valid(mem_axi.awvalid),
        .io_hbm_aw_bits_addr(mem_axi.awaddr),
        .io_hbm_aw_bits_id(mem_axi.awid),
        .io_hbm_aw_bits_len(mem_axi.awlen),
        .io_hbm_aw_bits_size(mem_axi.awsize),
        .io_hbm_aw_bits_burst(mem_axi.awburst),
        .io_hbm_aw_bits_lock(mem_axi.awlock),
        .io_hbm_aw_bits_cache(mem_axi.awcache),
        .io_hbm_aw_bits_prot(mem_axi.awprot),
        .io_hbm_aw_bits_qos(mem_axi.awqos),
        .io_hbm_w_ready(mem_axi.wready),
        .io_hbm_w_valid(mem_axi.wvalid),
        .io_hbm_w_bits_data(mem_axi.wdata),
        .io_hbm_w_bits_strb(mem_axi.wstrb),
        .io_hbm_w_bits_last(mem_axi.wlast),
        .io_hbm_b_ready(mem_axi.bready),
        .io_hbm_b_valid(mem_axi.bvalid),
        .io_hbm_b_bits_id(mem_axi.bid),
        .io_hbm_b_bits_resp(mem_axi.bresp),
        .io_hbm_r_ready(mem_axi.rready),
        .io_hbm_r_valid(mem_axi.rvalid),
        .io_hbm_r_bits_id(mem_axi.rid),
        .io_hbm_r_bits_data(mem_axi.rdata),
        .io_hbm_r_bits_resp(mem_axi.rresp),
        .io_hbm_r_bits_last(mem_axi.rlast),
        .io_legacy_ar_ready(periph_axi.arready),
        .io_legacy_ar_valid(periph_axi.arvalid),
        .io_legacy_ar_bits_addr(periph_axi.araddr),
        .io_legacy_ar_bits_id(periph_axi.arid),
        .io_legacy_ar_bits_len(periph_axi.arlen),
        .io_legacy_ar_bits_size(periph_axi.arsize),
        .io_legacy_ar_bits_burst(periph_axi.arburst),
        .io_legacy_ar_bits_lock(periph_axi.arlock),
        .io_legacy_ar_bits_cache(periph_axi.arcache),
        .io_legacy_ar_bits_prot(periph_axi.arprot),
        .io_legacy_ar_bits_qos(periph_axi.arqos),
        .io_legacy_aw_ready(periph_axi.awready),
        .io_legacy_aw_valid(periph_axi.awvalid),
        .io_legacy_aw_bits_addr(periph_axi.awaddr),
        .io_legacy_aw_bits_id(periph_axi.awid),
        .io_legacy_aw_bits_len(periph_axi.awlen),
        .io_legacy_aw_bits_size(periph_axi.awsize),
        .io_legacy_aw_bits_burst(periph_axi.awburst),
        .io_legacy_aw_bits_lock(periph_axi.awlock),
        .io_legacy_aw_bits_cache(periph_axi.awcache),
        .io_legacy_aw_bits_prot(periph_axi.awprot),
        .io_legacy_aw_bits_qos(periph_axi.awqos),
        .io_legacy_w_ready(periph_axi.wready),
        .io_legacy_w_valid(periph_axi.wvalid),
        .io_legacy_w_bits_data(periph_axi.wdata),
        .io_legacy_w_bits_strb(periph_axi.wstrb),
        .io_legacy_w_bits_last(periph_axi.wlast),
        .io_legacy_b_ready(periph_axi.bready),
        .io_legacy_b_valid(periph_axi.bvalid),
        .io_legacy_b_bits_id(periph_axi.bid),
        .io_legacy_b_bits_resp(periph_axi.bresp),
        .io_legacy_r_ready(periph_axi.rready),
        .io_legacy_r_valid(periph_axi.rvalid),
        .io_legacy_r_bits_id(periph_axi.rid),
        .io_legacy_r_bits_data(periph_axi.rdata),
        .io_legacy_r_bits_resp(periph_axi.rresp),
        .io_legacy_r_bits_last(periph_axi.rlast)
    );

    hbm_axi_bridge u_memory (
        .clk_cpu       (clk_cpu),
        .resetn_cpu    (resetn_cpu),
        .clk225      (clk225),
        .resetn225   (resetn225),
        .clk100      (clk100),
        .resetn100   (resetn100),
        .hbm_ready   (hbm_ready),
        .hbm_cattrip (hbm_cattrip_raw),
        .hbm_temp    (hbm_temp),
        .axi_debug_clear(vio_clear_axi_debug),
        .axi_debug   (hbm_axi_debug),
        .s_axi       (mem_axi)
    );

    // Never mask the HBM IP's thermal shutdown indication with init status.
    // The configured single left stack exports DRAM_0_STAT_CATTRIP.
    assign HBM_CATTRIP = hbm_cattrip_raw;

    // These are independent diagnostic levels, not a coherent data word.
    // Synchronize each bit before the reference-clocked VIO samples it.
    assign status_raw = {cpu_run, hbm_cattrip_raw, hbm_ready, resetn225,
                         resetn_cpu, resetn100, resetn100, clk_locked};
    for (genvar i = 0; i < 8; i++) begin : g_status_sync
        xpm_cdc_single #(.DEST_SYNC_FF(3), .SRC_INPUT_REG(0), .INIT_SYNC_FF(0))
        u_sync (.src_clk(1'b0), .src_in(status_raw[i]), .dest_clk(clk100), .dest_out(status_ref[i]));
    end
    vio_status_0 u_status_vio (
        .clk       (clk100),
        .probe_in0 (status_ref),
        .probe_out0(vio_force_cpu_reset)
    );

    vio_hbm_0 u_hbm_vio (
        .clk       (clk225),
        .probe_in0 (hbm_axi_debug),
        .probe_out0(vio_clear_axi_debug)
    );

    jtag_uart_16550 u_uart (
        .clk        (clk_cpu),
        .resetn     (resetn_cpu),
        .hbm_ready  (hbm_ready_cpu),
        .clk_locked (clk_locked),
        .cpu_halted (cpu_reset),
        .cpu_run    (cpu_run),
        .irq        (uart_irq),
        .s_axi      (periph_axi)
    );
endmodule
